module.exports = {
  lintOnSave: true,
};
