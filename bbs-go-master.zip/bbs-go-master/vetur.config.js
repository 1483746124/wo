// vetur.config.js
module.exports = {
    projects: [
        './site',
        './admin'
    ]
}